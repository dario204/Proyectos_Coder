from setuptools import setup, find_packages

setup(name= 'Segunda pre-entrega+Rodriguez',
    version='0.1',
    packages= find_packages(), 
    desciption= 'Segunda pre-entrega',
    author= 'Rodrgiuez Dario',
    autor_email= 'dario.rod551@gmail.com',
    keywords= 'pre-entrega')